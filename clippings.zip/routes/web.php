<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

// Clippings
Route::resource('clippings', 'ClippingsController');

// Clients
Route::resource('clients', 'ClientsController');

// Vehicles
Route::resource('vehicles', 'VehiclesController');

// Editorials
Route::resource('editorials', 'EditorialsController');

// Subjects
Route::resource('subjects', 'SubjectsController');

// Summaries
Route::resource('summaries', 'SummariesController');

// Ajax Calls
Route::group(['prefix' => 'ajax', 'middleware' => 'cors', 'as' => 'ajax.'], function() {
    Route::resource('clients', 'Ajax\ClientsController');
//    Route::resource('clippings', 'Ajax\ClippingsController');
    Route::resource('vehicles', 'Ajax\VehiclesController');
    Route::resource('editorials', 'Ajax\EditorialsController');
    Route::resource('subjects', 'Ajax\SubjectsController');
    Route::resource('summaries', 'Ajax\SummariesController');

    Route::resource('middles', 'Ajax\MiddlesController');

    // Not Resource routes
    Route::resource('states', 'Ajax\StatesController');
    Route::get('vehiclesAll', 'Ajax\VehiclesController@getVehicles')->name('getVehicles');
    Route::get('citiesAll/{id}', 'Ajax\CitiesController@getCities')->name('getCities'); // Get By ID (state_id)

    // Lists to populate selects
    //Route::get('lists/vehicles', 'Ajax\VehiclesController@lists')->name('vehicles.lists');
});
