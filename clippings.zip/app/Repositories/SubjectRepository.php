<?php
namespace App\Repositories;

use App\Models\Subject;
use Prettus\Repository\Eloquent\BaseRepository;

class SubjectRepository extends BaseRepository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return Subject::class;
    }
}
