<?php

namespace App\Http\Controllers\Ajax;

use App\Http\Controllers\Controller;
use App\Models\Client;
use Guiliredu\BrazilianCityMigrationSeed\Models\State;
use Yajra\DataTables\DataTables;

class StatesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return State::all();
    }
}
