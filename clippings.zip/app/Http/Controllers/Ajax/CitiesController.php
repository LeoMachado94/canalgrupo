<?php

namespace App\Http\Controllers\Ajax;

use App\Http\Controllers\Controller;
use App\Models\Client;
use Guiliredu\BrazilianCityMigrationSeed\Models\City;
use Guiliredu\BrazilianCityMigrationSeed\Models\State;
use Yajra\DataTables\DataTables;

class CitiesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function getCities($id)
    {
        return City::where('state_id', $id)->get();
    }
}
