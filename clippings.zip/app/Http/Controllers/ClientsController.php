<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Repositories\ClientRepository;
use App\Validators\ClientValidator;
use Illuminate\Http\Request;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;

class ClientsController extends Controller
{
    protected $repository;
    protected $validator;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(ClientRepository $repository, ClientValidator $validator)
    {
        $this->middleware('auth');
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * Show the application clients list.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('clients.index');
    }

    /**
     * Show the application clients create.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function create()
    {
        return view('clients.create');
    }

    public function store(Request $request)
    {
        $data = $request->all();
        $data['active'] = 1;
        try {
            $this->validator->with($data)->passesOrFail(ValidatorInterface::RULE_CREATE);
            $client = $this->repository->create($data);

            if ($client) {
                $phones = collect($data['phones']);
                /**
                 * @var Client $client
                 */
                $phones->each(function($phone) use ($client) {
                    $client->phones()->create(
                        ['phone_number' => $phone]
                    );
                });
            }

            // Upload Profile img
            if($request->hasFile('logo')) {
                $image = $request->file('logo');
                $imageName = uniqid().'.'.$image->getClientOriginalExtension();
                $path = 'assets/images/clients';
                $image->move(public_path($path), $imageName);

                $client->logo = $path.'/'.$imageName;
                $client->save();
            }
            return redirect()->route('clients.index')->with([
                'success' => true,
                'title' => 'Cadastrado!',
                'message' => 'Cliente cadastrado com sucesso',
                'icon' => 'success'
            ]);
        } catch (ValidatorException $e) {
            return redirect()->back()->withInput()->withErrors($e->getMessageBag());
        }
    }

    public function show($id)
    {
        $client = $this->repository->find($id);
        return view('clients.show', compact('client'));
    }

    public function edit($id)
    {
        $client = $this->repository->find($id);
        return view('clients.edit', compact('client'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->all();
        try {
            $this->validator->with($data)->passesOrFail(ValidatorInterface::RULE_UPDATE);
            $client = $this->repository->update($data, $id);

            if ($client) {
                $phones = collect($data['phones']);
                /**
                 * @var Client $client
                 */
                $client->phones()->delete();
                $phones->each(function($phone) use ($client) {
                    $client->phones()->create(
                        ['phone_number' => $phone]
                    );
                });
            }

            // Upload Profile img
            if($request->hasFile('logo')) {
                $image = $request->file('logo');
                $imageName = uniqid().'.'.$image->getClientOriginalExtension();
                $path = 'assets/images/clients';
                $image->move(public_path($path), $imageName);

                $client->logo = $path.'/'.$imageName;
                $client->save();
            }
            return redirect()->route('clients.index')->with([
                'success' => true,
                'title' => 'Atualizado!',
                'message' => 'Cliente atualizado com sucesso',
                'icon' => 'success'
            ]);
        } catch (ValidatorException $e) {
            return redirect()->back()->withInput()->withErrors($e->getMessageBag());
        }
    }
}
