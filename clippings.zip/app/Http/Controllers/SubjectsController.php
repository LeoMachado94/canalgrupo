<?php

namespace App\Http\Controllers;

use App\Models\Subject;
use App\Repositories\SubjectRepository;
use App\Validators\SubjectValidator;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Prettus\Validator\Contracts\ValidatorInterface;
use Prettus\Validator\Exceptions\ValidatorException;

class SubjectsController extends Controller
{
    protected $repository;
    protected $validator;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(SubjectRepository $repository, SubjectValidator $validator)
    {
        $this->middleware('auth');
        $this->repository = $repository;
        $this->validator = $validator;
    }

    /**
     * Show the application subjects list.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('subjects.index');
    }

    /**
     * Show the application subjects create.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function create()
    {
        return view('subjects.create');
    }

    public function store(Request $request)
    {
        $data = $request->all();
        $data['user_id'] = Auth::user()->id;

        $date = Carbon::createFromFormat('d/m/Y', '01/'.$data['date']);
        $data['date'] = $date->format('Y').'-'.$date->format('m').'-01';

        try {
            $this->validator->with($data)->passesOrFail(ValidatorInterface::RULE_CREATE);
            $vehicle = $this->repository->create($data);

            return redirect()->route('subjects.index')->with([
                'success' => true,
                'title' => 'Cadastrado!',
                'message' => 'Assunto cadastrado com sucesso',
                'icon' => 'success'
            ]);
        } catch (ValidatorException $e) {
            return redirect()->back()->withInput()->withErrors($e->getMessageBag());
        }
    }

    public function show($id)
    {
        $subject = $this->repository->find($id);
        return view('subjects.show', compact('subject'));
    }

    public function edit($id)
    {
        $subject = $this->repository->find($id);
        return view('subjects.edit', compact('subject'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->all();
        $data['user_id'] = Auth::user()->id;

        $date = Carbon::createFromFormat('d/m/Y', '01/'.$data['date']);
        $data['date'] = $date->format('Y').'-'.$date->format('m').'-01';
        try {
            $this->validator->with($data)->passesOrFail(ValidatorInterface::RULE_UPDATE);
            $editorial = $this->repository->update($data, $id);

            return redirect()->route('subjects.index')->with([
                'success' => true,
                'title' => 'Atualizado!',
                'message' => 'Assunto atualizado com sucesso',
                'icon' => 'success'
            ]);
        } catch (ValidatorException $e) {
            return redirect()->back()->withInput()->withErrors($e->getMessageBag());
        }
    }
}
