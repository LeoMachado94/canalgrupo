<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <?php echo $__env->make('layouts.header', [
        'header_title' => 'Editar Assunto',
        'header_subtitle' => 'Alterar cadastro de assunto',
        'header_subtitle_icon' => 'fas fa-comments',
        'btns' => [
            [
            'icon' => 'fas fa-arrow-left',
            'text' => 'Voltar',
            'link' => url()->previous()
            ]
        ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="card mb-4">
            <!-- Card header -->
            <div class="card-header">
                <h3 class="mb-0">Editar Assunto</h3>
            </div>
            <!-- Card body -->
            <div class="card-body">
                <!-- Form groups used in grid -->
                <form class="form-save" method="POST" action="<?php echo e(route('subjects.update', $subject->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-control-label" for="Client">Cliente</label>
                            <select class="form-control <?php $__errorArgs = ['client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="client_id"
                                    id="Client" data-toggle="select">
                                <option>Selecione o Cliente</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-control-label" for="Title">Título</label>
                                <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('title') ?? $subject->title); ?>" id="Title" placeholder="Qual o Título do Assunto ?">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-control-label" for="Date">Data</label>
                                <input type="text" name="date" class="form-control date <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('date') ?? $subject->date); ?>" id="Hour" placeholder="Qual a Data do Assunto ?">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-control-label" for="Active">Situação</label>
                                <select class="form-control <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="active"
                                        id="Active" data-toggle="select">
                                    <option value="1">Ativo</option>
                                    <option value="0">Inativo</option>
                                </select>
                            </div>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="col-md-12">
                                <div class="alert alert-danger">
                                    <?php echo e($errors->first()); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card-body text-center">
            <button type="button" class="btn btn-cancelar btn-lg">Cancelar</button>
            <button type="button" class="btn btn-salvar btn-lg btn-save">SALVAR</button>
        </div>

        <!-- Footer -->
        <footer class="footer pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-12">
                    <div class="copyright text-center text-muted">
                        &copy; 2020 <a href="#" class="font-weight-1 ml-1" target="_blank">Canal Grupo - Todos os direitos reservados.</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<!-- Page plugins -->
<link rel="stylesheet" href="<?php echo e(asset('template/assets/vendor/select2/dist/css/select2.min.css')); ?>">
<style type="text/css">
.actions {
    display: table-cell;
    vertical-align: middle !important;
}
.table-action i {
    font-size: 20px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('template/assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/js-cookie/js.cookie.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>

<!-- Optional JS -->
<script src="<?php echo e(asset('template/assets/vendor/select2/dist/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery_mask/jquery.mask.min.js')); ?>"></script>


<script type="text/javascript">
    function setActive(active)
    {
        $("#Active").val(active).trigger('change');
    }

    function setClient(clientId)
    {
        if ($("#Client option").length > 1) {
            $("#Client").val(clientId).trigger('change');
        }
    }

    $(document).ready(function() {
        $('.btn-save').on('click', function (){
            $('.form-save').submit();
        });

        <?php if(!is_null($subject->client_id)): ?>
        let timerClient = setTimeout(() => setClient('<?php echo e($subject->client_id); ?>'), 1000);
        <?php endif; ?>
        <?php if(!is_null($subject->active)): ?>
            let timerActive = setTimeout(() => setActive('<?php echo e($subject->active); ?>'), 500);
        <?php endif; ?>

        $.ajax({
            type: 'GET',
            url: '<?php echo e(route('ajax.clients.index')); ?>',
            success: function (res) {
                let select = $('#Client');
                select.html('');
                select.append('<option value="0">Selecione o Cliente</option>');

                $(res.data).each(function (index, value) {
                   select.append('<option value="'+value.id+'">'+value.name+'</option>')
                });
            }
        });

        <?php if($errors->any()): ?>
            <?php if(old('client_id')): ?>
                let timer1 = setTimeout(() => setClient('<?php echo e(old('client_id')); ?>'), 1000);
            <?php endif; ?>
            <?php if(old('active')): ?>
                let timer2 = setTimeout(() => setActive('<?php echo e(old('active')); ?>'), 500);
            <?php endif; ?>
        <?php endif; ?>

        // Mask
        $('.date').mask('00/0000', {placeholder: 'mm/aaaa'});
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leona\projects\clippings\resources\views/subjects/edit.blade.php ENDPATH**/ ?>