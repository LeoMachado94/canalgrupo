<div class="header bg-primary pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-7 col-7">
                    <h6 class="h2 text-white d-inline-block mb-0"><?php echo e($header_title ?? ''); ?></h6>
                    <?php if(isset($header_subtitle) && isset($header_subtitle_icon)): ?>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="#"><i class="<?php echo e($header_subtitle_icon ?? ''); ?>"></i></a></li>
                            <li class="breadcrumb-item"><a href="#"><?php echo e($header_subtitle ?? ''); ?></a></li>
                        </ol>
                    </nav>
                    <?php endif; ?>
                </div>
                <div class="col-lg-5 col-5 text-right">
                    <?php $__currentLoopData = $btns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $btn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($btn['link'] ?? 'link'); ?>" class="btn <?php echo e($btn['class'] ?? 'btn-secondary'); ?> btn-icon">
                            <span class="btn-inner--icon"><i class="<?php echo e($btn['icon'] ?? 'icon'); ?>"></i></span>
                            <span class="btn-inner--text"><?php echo e($btn['text'] ?? 'text'); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\leona\projects\clippings\resources\views/layouts/header.blade.php ENDPATH**/ ?>