<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <?php echo $__env->make('layouts.header', [
        'btns' => [
            [
            'icon' => 'fas fa-arrow-left',
            'text' => 'Voltar',
            'link' => route('clippings.index')
            ]
        ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="card mb-4">
            <!-- Card header -->
            <div class="card-header">
                <h3 class="mb-0">Cadastro de Clipping</h3>
            </div>
            <!-- Card body -->
            <div class="card-body">
                <!-- Form groups used in grid -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="exampleFormControlSelect1">Cliente</label>
                            <select class="form-control" data-toggle="select">
                                <option>Escolha o cliente</option>
                                <option>Associação comercial e Industrial de Imperatriz</option>
                                <option>Canal Grupo LTDA</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="QualoAssunto">Assunto</label>
                            <input type="text" class="form-control" id="QualoAssunto" placeholder="Qual o Assunto do Clipping">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Titulo">Título</label>
                            <input type="text" class="form-control" id="Titulo" placeholder="Qual o Título do Clipping">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="exampleFormControlSelect1">Meio</label>
                            <select class="form-control" data-toggle="select">
                                <option>Escolha o Meio</option>
                                <option>TV</option>
                                <option>Rádio</option>
                                <option>Impresso</option>
                                <option>Rede social</option>
                                <option>Site/Blog</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="exampleFormControlSelect1">Veículo</label>
                            <select class="form-control" data-toggle="select">
                                <option>Escolha o Veículo</option>
                                <option>TV MIRANTE</option>
                                <option>TV DIFUSORA</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="exampleFormControlSelect1">Programa</label>
                            <select class="form-control" data-toggle="select">
                                <option>Escolha o Programa</option>
                                <option>Bom dia Mirante</option>
                                <option>Globo Esporte</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="exampleFormControlSelect1">Classificação</label>
                            <select class="form-control" data-toggle="select">
                                <option>Escolha a Classificação</option>
                                <option>Positiva</option>
                                <option>Favorável</option>
                                <option>Negativa</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="exampleFormControlSelect1">Exibição</label>
                            <select class="form-control" data-toggle="select">
                                <option>Escolha a Exibição</option>
                                <option>Comentário</option>
                                <option>Entrevista</option>
                                <option>Manchete</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="exampleFormControlSelect1">Fonte</label>
                            <select class="form-control" data-toggle="select">
                                <option>Escolha a Fonte</option>
                                <option>Espontânea</option>
                                <option>Gerada</option>
                                <option>Mista</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-3">
                        <div class="form-group">
                            <label class="form-control-label" for="exampleDatepicker">Data</label>
                            <input class="form-control datepicker" placeholder="Select date" type="text" value="06/20/2018">
                        </div>
                    </div>

                </div>

            </div>
        </div>

        <!-- Dropzone -->
        <div class="card">
            <!-- Card header -->
            <div class="card-header">
                <h3 class="mb-0">Selecione o arquivo</h3>
            </div>
            <!-- Card body -->
            <div class="card-body">
                <!-- Multiple -->
                <div class="dropzone dropzone-multiple" data-toggle="dropzone" data-dropzone-multiple data-dropzone-url="http://">
                    <div class="fallback">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="customFileUploadMultiple" multiple>
                            <label class="custom-file-label" for="customFileUploadMultiple">Choose file</label>
                        </div>
                    </div>
                    <ul class="dz-preview dz-preview-multiple list-group list-group-lg list-group-flush">
                        <li class="list-group-item px-0">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <div class="avatar">
                                        <img class="avatar-img rounded" src="<?php echo e(asset('template/assets/img/theme/team-4.jpg')); ?>" alt="Dropzone" data-dz-thumbnail>
                                    </div>
                                </div>
                                <div class="col ml--3">
                                    <h4 class="mb-1" data-dz-name>...</h4>
                                    <p class="small text-muted mb-0" data-dz-size>...</p>
                                </div>
                                <div class="col-auto">
                                    <div class="dropdown">
                                        <a href="#" class="dropdown-ellipses dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fe fe-more-vertical"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a href="#" class="dropdown-item" data-dz-remove>
                                                Deletar
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- resenha -->
        <div class="card">
            <!-- Card header -->
            <div class="card-header">
                <h3 class="mb-0">Resenha</h3>
            </div>
            <!-- Card body -->
            <div class="card-body">
                <form>
                    <div data-toggle="quill" data-quill-placeholder="Digite aqui a resenha"></div>
                </form>
            </div>
        </div>
        <!-- fim -->


        <div class="card-body text-center">
            <button type="button" class="btn btn-cancelar btn-lg">Cancelar</button>
            <button type="button" class="btn btn-salvar btn-lg">SALVAR</button>
        </div>

        <!-- Footer -->
        <footer class="footer pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-12">
                    <div class="copyright text-center text-muted">
                        &copy; 2020 <a href="#" class="font-weight-1 ml-1" target="_blank">Canal Grupo - Todos os direitos reservados.</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="icon" href="<?php echo e(asset('template/assets/img/brand/favicon.png')); ?>" type="image/png">
<!-- Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
<!-- Icons -->
<link rel="stylesheet" href="<?php echo e(asset('template/assets/vendor/nucleo/css/nucleo.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('template/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>" type="text/css">
<!-- Page plugins -->
<link rel="stylesheet" href="<?php echo e(asset('template/assets/vendor/select2/dist/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('template/assets/vendor/quill/dist/quill.core.css')); ?>">
<!-- Argon CSS -->
<link rel="stylesheet" href="<?php echo e(asset('template/assets/css/argon.css?v=1.1.0')); ?>" type="text/css">
<style type="text/css">
    .dz-message {
        z-index: 10 !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('template/assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/js-cookie/js.cookie.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>

<!-- Optional JS -->
<script src="<?php echo e(asset('template/assets/vendor/select2/dist/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/nouislider/distribute/nouislider.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/quill/dist/quill.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/dropzone/dist/min/dropzone.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leona\projects\clippings\resources\views/clippings/create.blade.php ENDPATH**/ ?>