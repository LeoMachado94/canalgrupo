<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <?php echo $__env->make('layouts.header', [
        'header_title' => __('messages.clippings.header.title'),
        'header_subtitle' => __('messages.clippings.header.subtitle.index'),
        'header_subtitle_icon' => 'fas fa-users',
        'btns' => [
            [
            'icon' => 'fas fa-plus',
            'text' => __('messages.clippings.header.btns.create'),
            'link' => route('clippings.create')
            ]
        ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col">
                <div class="card" id="table" style="padding: 0 1rem;">
                    <!-- Card header -->
                    <div class="card-header pl-0 border-0">
                        <h3 class="mb-0"><?php echo __('messages.clippings.page.title.index'); ?></h3>
                    </div>
                    <!-- Light table -->
                    <table class="table table-responsive align-items-center table-flush">
                        <thead class="thead-light">
                        <tr>
                            <th scope="col" class="sort" data-sort="n">Nº</th>
                            <th scope="col" class="sort" data-sort="data_veic">Data de Veiculação</th>
                            <th scope="col" class="sort" data-sort="data_cad">Data de Cadastro</th>
                            <th scope="col" class="sort" data-sort="client">Cliente</th>
                            <th scope="col" class="sort" data-sort="type">Tipo</th>
                            <th scope="col" class="sort" data-sort="meio">Meio</th>
                            <th scope="col" class="sort" data-sort="classificacao">Classificação</th>
                            <th scope="col" class="sort" data-sort="user">Usuário</th>
                            <th scope="col" class="sort" data-sort="opcoes">Opções</th>
                        </tr>
                        </thead>
                        <tbody class="list">
                        <!-- inicio list -->
                        <tr>
                            <td>190935</td>
                            <td><span class="text-muted">10/09/2019</span></td>
                            <td><span class="text-muted">10/09/2019</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <!-- fim list -->

                        <!-- inicio list -->
                        <tr>
                            <td>190936</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190937</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190938</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190933</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190933</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190933</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190933</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190933</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190955</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190955</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190955</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td>190955</td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <td><span class="text-muted">10/09/2018</span></td>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/bootstrap.jpg')); ?>">
                                    </a>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">Associação Comercial e Industrial de Imperatriz</span>
                                    </div>
                                </div>
                            </th>
                            <td class="budget">Espontânea</td>
                            <td class="budget">Site/Blog</td>
                            <td>
                      <span class="badge badge-dot mr-4">
                        <i class="bg-success"></i>
                        <span class="status">Positiva</span>
                      </span>
                            </td>
                            <td>
                                <div class="avatar-group">
                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="Ryan Tompson">
                                        <img alt="Image placeholder" src="<?php echo e(asset('template/assets/img/theme/team-1.jpg')); ?>">
                                    </a>
                                </div>
                            </td>
                            <td class="table-actions">
                                <a href="#!" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#!" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Deletar">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>

                        <!-- fim list -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-12">
                    <div class="copyright text-center text-muted">
                        &copy; 2020 <a href="#" class="font-weight-1 ml-1" target="_blank">Canal Grupo - Todos os direitos reservados.</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('template/assets/plugins/datatables/1.10.18/css/dataTables.bootstrap4.min.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<!-- Optional JS -->
<script src="<?php echo e(asset('template/assets/plugins/datatables/1.10.18/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/plugins/datatables/1.10.18/js/dataTables.bootstrap4.min.js')); ?>"></script>

<script>
    $(document).ready(function() {
        $('.table').DataTable( {
            "dom": '<"row"<"col-md-8"l><"col-md-4"f>><"table-responsive"t><"row"<"col-md-8"i><"col-md-4"<"buttons-pagination"p>>>',
            "pageLength": 10,
            "language": {
                "url": "<?php echo e(asset('template/translations/datatable/pt-br.json')); ?>",
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leona\projects\clippings\resources\views/clippings/index.blade.php ENDPATH**/ ?>