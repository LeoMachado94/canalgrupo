<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <?php echo $__env->make('layouts.header', [
        'header_title' => 'Novo cliente',
        'header_subtitle' => 'Cadastro de clientes da empresa',
        'header_subtitle_icon' => 'fas fa-users',
        'btns' => [
            [
            'icon' => 'fas fa-arrow-left',
            'text' => 'Voltar',
            'link' => url()->previous()
            ]
        ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="card mb-4">
            <!-- Card header -->
            <div class="card-header">
                <h3 class="mb-0">Cadastro de Clientes</h3>
            </div>
            <!-- Card body -->
            <div class="card-body">
                <!-- Form groups used in grid -->
                <form class="form-save" method="POST" action="<?php echo e(route('clients.store')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-12">
                        <h2 class="text-red">Informações Gerais</h2>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Name">Nome</label>
                            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('name') ?? ''); ?>" id="Name" placeholder="Qual o Nome da Empresa ?">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Cnpj">CNPJ</label>
                            <input type="text" name="cnpj" class="form-control cnpj <?php $__errorArgs = ['cnpj'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('cnpj') ?? ''); ?>" id="Cnpj" placeholder="Qual o CNPJ da Empresa ?">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="State">Estado</label>
                            <select class="form-control <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="state_id"
                                    id="State" data-toggle="select">
                                <option>Selecione o Estado</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="City">Cidade</label>
                            <select class="form-control <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city_id"
                                    id="City" data-toggle="select">
                                <option>Selecione a Cidade</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Contact">Contato</label>
                            <input type="text" name="contact" class="form-control <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('contact') ?? ''); ?>" id="Contact" placeholder="Qual o Contato Responsável ?">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Email">Email</label>
                            <input type="text" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Email" placeholder="Qual o Email ?">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-control-label" for="Logo">Logo</label>
                        <input type="file" name="logo" class="form-control" id="Logo">
                    </div>
                    <div class="col-md-6">
                        <img id="previewLogo" class="img-fluid" src="<?php echo e(asset('assets/images/no_image.png')); ?>" style="max-width: 300px;">
                    </div>
                    <div class="col-md-12">
                        <hr style="border-color: #E33039;">
                    </div>
                    <div class="col-md-6">
                        <h2 class="text-red">Telefones</h2>
                        <table class="table" id="phones">
                            <thead>
                                <tr>
                                    <th>Número</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                            </div>
                                            <input type="text" name="phones[]" class="form-control phone">
                                        </div>
                                    </td>
                                    <td class="actions">
                                        <a href="#" class="table-action table-action-add add-phone" data-toggle="tooltip" data-original-title="Novo">
                                            <i class="fas fa-plus"></i>
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                </form>
            </div>
        </div>

        <div class="card-body text-center">
            <button type="button" class="btn btn-cancelar btn-lg">Cancelar</button>
            <button type="button" class="btn btn-salvar btn-lg btn-save">SALVAR</button>
        </div>

        <!-- Footer -->
        <footer class="footer pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-12">
                    <div class="copyright text-center text-muted">
                        &copy; 2020 <a href="#" class="font-weight-1 ml-1" target="_blank">Canal Grupo - Todos os direitos reservados.</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<!-- Page plugins -->
<link rel="stylesheet" href="<?php echo e(asset('template/assets/vendor/select2/dist/css/select2.min.css')); ?>">
<style type="text/css">
.actions {
    display: table-cell;
    vertical-align: middle !important;
}
.table-action i {
    font-size: 20px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('template/assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/js-cookie/js.cookie.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>

<!-- Optional JS -->
<script src="<?php echo e(asset('template/assets/vendor/select2/dist/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery_mask/jquery.mask.min.js')); ?>"></script>


<script type="text/javascript">
    function readURL(imageInput) {
        if (imageInput.files && imageInput.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                $('#previewLogo').attr('src', e.target.result);
            }

            reader.readAsDataURL(imageInput.files[0]);
        }
    }

    function setState(stateId)
    {
        if ($("#State option").length > 1) {
            $("#State").val(stateId).trigger('change');
        }
    }

    function setCity(cityId)
    {
        if ($("#City option").length > 1) {
            $("#City").val(cityId).trigger('change');
        }
    }

    $(document).ready(function() {
        $('.btn-save').on('click', function (){
            $('.form-save').submit();
        });

        $('#Logo').change(function() {
            readURL(this);
        });

        $('body').on('click', '.add-phone', function(e) {
            e.preventDefault();
            let buttonDelete =
                '<a href="#" class="table-action table-action-delete delete-phone" data-toggle="tooltip" data-original-title="Deletar">\n' +
                '<i class="fas fa-trash"></i>\n' +
                '</a>';
            let row = $('#phones tbody tr:last').clone().find("input:text").val("").end().appendTo('#phones tbody');
            if (!row.find('.delete-phone').length) {
                row.find('.actions').prepend(buttonDelete);
            }
            $('.phone').mask(SPMaskBehavior, spOptions);
        });

        $('body').on('click', '.delete-phone', function(e) {
            e.preventDefault();
            $(this).closest('tr').remove();
        });

        $.ajax({
            type: 'GET',
            url: '<?php echo e(route('ajax.states.index')); ?>',
            success: function (res) {
                let select = $('#State');
                select.html('');
                select.append('<option value="0">Selecione o Estado</option>');

                $(res).each(function (index, value) {
                   select.append('<option value="'+value.id+'">'+value.title+'</option>')
                });
            }
        });

        $('#State').on('change', function() {
            let select = $('#City');
            select.prop('disabled', true);
            select.html('');
            select.append('<option value="0">Carregando...</option>');

            let state_id = $(this).val();
            if (state_id !== 0) {

               let url = '<?php echo e(route('ajax.getCities', 'ID')); ?>';
               url = url.replace('ID', state_id);

                $.ajax({
                    type: 'GET',
                    url: url,
                    success: function (res) {
                        let select = $('#City');
                        select.html('');
                        select.append('<option value="0">Selecione a Cidade</option>');
                        $(res).each(function (index, value) {
                           select.append('<option value="'+value.id+'">'+value.title+'</option>')
                        });
                        $('#City').prop('disabled', false);
                    }
                });
            }
        });

        <?php if($errors->any()): ?>
            <?php if(old('state_id')): ?>
            let timer1 = setTimeout(() => setState('<?php echo e(old('state_id')); ?>'), 1000);
            <?php endif; ?>

            <?php if(old('city_id')): ?>
            let timer2 = setTimeout(() => setCity('<?php echo e(old('city_id')); ?>'), 2000);
            <?php endif; ?>
        <?php endif; ?>

        // Mask
        $('.cnpj').mask('00.000.000/0000-00', {placeholder: '00.000.000/0000-00'});

        var SPMaskBehavior = function (val) {
                return val.replace(/\D/g, '').length === 11 ? '(00) 00000 0000' : '(00) 0000 00009';
            },
            spOptions = {
                onKeyPress: function(val, e, field, options) {
                    field.mask(SPMaskBehavior.apply({}, arguments), options);
                },
                placeholder: '(00) 00000 0000'
            };

        $('.phone').mask(SPMaskBehavior, spOptions);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leona\projects\clippings\resources\views/clients/create.blade.php ENDPATH**/ ?>