<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <?php echo $__env->make('layouts.header', [
        'header_title' => 'Visualizar Editorial/Programa',
        'header_subtitle' => 'Visualização de editoriais/programas',
        'header_subtitle_icon' => 'fas fa-newspaper',
        'btns' => [
            [
            'icon' => 'fas fa-arrow-left',
            'text' => 'Voltar',
            'link' => url()->previous()
            ]
        ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="card mb-4">
            <!-- Card header -->
            <div class="card-header">
                <h3 class="mb-0">Visualização de Editoriais/Programas</h3>
            </div>
            <!-- Card body -->
            <div class="card-body">
                <!-- Form groups used in grid -->
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-6">
                        <label class="form-control-label" for="Vehicle">Veículo</label>
                        <div><?php echo e($editorial->vehicle->name); ?></div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Title">Título</label>
                            <div><?php echo e($editorial->title ?? ''); ?></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Hour">Horário</label>
                            <div><?php echo e(\Carbon\Carbon::createFromFormat('H:i:s', $editorial->hour)->format('H:i') ?? ''); ?></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Responsible">Responsável</label>
                            <div><?php echo e($editorial->responsible ?? ''); ?></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Active">Situação</label>
                            <div><?php echo e($editorial->active ? 'Ativo' : 'Inativo'); ?></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-control-label" for="Description">Descrição</label>
                            <div><?php echo $editorial->description ?? ''; ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-12">
                    <div class="copyright text-center text-muted">
                        &copy; 2020 <a href="#" class="font-weight-1 ml-1" target="_blank">Canal Grupo - Todos os direitos reservados.</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('template/assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/js-cookie/js.cookie.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leona\projects\clippings\resources\views/editorials/show.blade.php ENDPATH**/ ?>