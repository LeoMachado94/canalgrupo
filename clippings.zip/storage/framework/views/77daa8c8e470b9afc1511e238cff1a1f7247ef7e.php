<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <?php echo $__env->make('layouts.header', [
        'header_title' => 'Veículos',
        'header_subtitle' => 'Veja aqui os veículos cadastrados',
        'header_subtitle_icon' => 'fas fa-bullhorn',
        'btns' => [
            [
            'icon' => 'fas fa-plus',
            'text' => 'Cadastrar novo',
            'link' => route('vehicles.create')
            ]
        ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col">
                <div class="card" style="padding: 0 1rem;">
                    <!-- Card header -->
                    <div class="card-header pl-0 border-0">
                        <h3 class="mb-0">Lista de veículos</h3>
                    </div>
                    <!-- Light table -->

                        <table class="table align-items-center table-flush" style="overflow: none; width: 100%;">
                            <thead class="thead-light">
                            <tr>
                                <th>Nome</th>
                                <th>Meio</th>
                                <th>Cidade</th>
                                <th>UF</th>
                                <th>Situação</th>
                                <th>Ações</th>
                            </tr>
                            </thead>
                            <tbody class="list">
                            </tbody>
                        </table>

                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-12">
                    <div class="copyright text-center text-muted">
                        &copy; 2020 <a href="#" class="font-weight-1 ml-1" target="_blank">Canal Grupo - Todos os direitos reservados.</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <div class="modal fade" id="modal-delete" tabindex="-1" role="dialog" aria-labelledby="modal-delete" aria-hidden="true">
        <div class="modal-dialog modal-danger modal-dialog-centered modal-10" role="document">
            <div class="modal-content bg-gradient-danger">

                <div class="modal-header">
                    <h6 class="modal-title" id="modal-title-delete">ATENÇÃO</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="py-3 text-center">
                        <i class="ni ni-bell-55 ni-3x"></i>
                        <h4 class="heading mt-4">Excluir veículo ?</h4>
                        <p>Após a exclusão será impossível recuperar o registro.</p>
                    </div>
                </div>

                <div class="modal-footer">
                    <form id="form-delete" type="POST" action="#">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-white btn-delete">Ok, Excluir!</button>
                    </form>
                    <button type="button" class="btn btn-link text-white ml-auto" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<!-- Page plugins -->
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables/1.10.18/css/dataTables.bootstrap4.min.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/plugins/datatables/1.10.18/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/1.10.18/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/sweetalert/sweetalert.min.js')); ?>"></script>

<script>
    let columns = [
        { data: 'name', name: 'name' },
        { data: 'middle', name: 'middle' },
        { data: 'city', name: 'city' },
        { data: 'state', name: 'state' },
        { data: 'active', name: 'active' },
        { data: 'actions', name: 'actions'}
    ];

    let middle = {
        "targets": 1,
        "data": "middle",
        "render": function(data, type, row, meta) {
            return row.middle.name;
        }
    };

    let city = {
        "targets": 2,
        "data": "city",
        "render": function(data, type, row, meta) {
            return row.city.title;
        }
    };

    let state = {
        "targets": 3,
        "data": "state",
        "render": function(data, type, row, meta) {
            return row.state.title;
        }
    };

    let status = {
        "targets": 4,
        "data": "active",
        "render": function(data, type, row, meta) {
            if (parseInt(row.active) === 1) {
                return 'Ativo';
            }
            return 'Inativo';
        }
    };

    let actions = {
        "targets": 5,
        "data": "actions",
        "render": function(data, type, row, meta) {
            let id = row.id;
            let showRoute = '<?php echo e(route('vehicles.show', 'ID')); ?>';
            let editRoute = '<?php echo e(route('vehicles.edit', 'ID')); ?>';
            let deleteRoute = '<?php echo e(route('ajax.vehicles.destroy', 'ID')); ?>';
            showRoute = showRoute.replace('ID', id);
            editRoute = editRoute.replace('ID', id);
            deleteRoute = deleteRoute.replace('ID', id);
            let btns = '<a href="'+showRoute+'" class="table-action table-action-visualizar" data-toggle="tooltip" data-original-title="Visualizar">' +
            '<i class="fas fa-eye"></i>' +
            '</a>' +
            '<a href="'+editRoute+'" class="table-action table-action-edit" data-toggle="tooltip" data-original-title="Editar">' +
            '<i class="far fa-edit"></i>' +
            '</a>' +
            '<a href="#" class="table-action table-action-delete btn-delete" data-route="'+deleteRoute+'" data-toggle="modal" data-target="#modal-delete" data-original-title="Deletar">' +
            '<i class="fas fa-trash"></i>' +
            '</a>';
            return btns;
        }
    }

    let columnDefs = [
        middle,
        city,
        state,
        status,
        actions
    ];

    $(document).ready(function() {
        var table = $('.table').DataTable( { //Blfrtip // lftipr
            "dom": '<"row"<"col-md-8"l><"col-md-4"f>><"table-responsive"t><"row"<"col-md-8"i><"col-md-4"<"buttons-pagination"pr>>>',
            "ajax": {
                "url": "<?php echo e(route('ajax.vehicles.index')); ?>",
            },
            "processing": true,
            "serverSide": true,
            "pageLength": 10,
            "responsive": true,
            "columns": columns,
            "columnDefs": columnDefs,
            "language": {
                // "processing": '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ',
                "url": "<?php echo e(asset('template/translations/datatable/pt-br.json')); ?>"
            }
        });

        <?php if(session()->get('success') == true): ?>
        swal({
            title: '<?php echo e(session()->get('title')); ?>',
            text: "<?php echo e(session()->get('message')); ?>",
            icon: "<?php echo e(session()->get('icon')); ?>",
            button: "OK!",
        });
        <?php endif; ?>

        $('body').on('click', '.btn-delete', function(e) {
            let route = $(this).data('route');
            let modal = $(this).data('target');
            $(modal).find('form').attr('action', route);
        });

        $('body').on('submit', '#form-delete', function(e) {
            e.preventDefault();
            let data = $(this).serialize();
            let url = $(this).attr('action');
            $.ajax({
                type: 'DELETE',
                data: data,
                url: url,
                success: function (res) {
                    swal({
                        title: res.title,
                        text: res.message,
                        icon: res.icon,
                        button: "OK!",
                    });
                    $('#modal-delete').modal('hide');
                    table.ajax.reload();
                }
            });
        });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\leona\projects\clippings\resources\views/vehicles/index.blade.php ENDPATH**/ ?>