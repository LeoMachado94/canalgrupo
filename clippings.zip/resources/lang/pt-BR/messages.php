<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Mensagens
    |--------------------------------------------------------------------------
    |
    | Mensagens e textos do sistema, incluindo títulos, cabeçalhos, botões
    |
    */

    'clippings' => [
        'header' => [
            'title' => 'Clippings',
            'subtitle' => [
                'index' => 'Veja aqui a lista de clippings cadastrados',
                'create' => 'Cadastre aqui os clippings',
                'edit' => 'Alterar as informações do cadastro de clippings',
                'show' => 'Visualizar informações de clippings',
            ],
            'btns' => [
                'create' => 'Cadastrar novo'
            ]
        ],
        'page' => [
            'title' => [
                'index' => 'Lista de clippings'
            ]
        ]
    ],
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',

];
