<?php

use Illuminate\Database\Seeder;

class ClientTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\Client::create([
            'state_id' => 22,
            'city_id' => 3432,
            'name' => 'Maria Rosa',
            'logo' => 'logo.jpeg',
            'cnpj' => '1321382913',
            'contact' => 'Paulo Guedes',
            'email' => 'maria@mar.com',
            'active' => true
        ]);
        \App\Models\Client::create([
            'state_id' => 22,
            'city_id' => 3112,
            'name' => 'Pedro Saraiva',
            'logo' => 'logo.jpeg',
            'cnpj' => '1321382913',
            'contact' => 'Paulo Guedes',
            'email' => 'pedro@mar.com',
            'active' => true
        ]);

    }
}
