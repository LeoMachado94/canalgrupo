<?php

use Illuminate\Database\Seeder;

class MiddleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\Middle::create([
            'id' => 1,
            'name' => 'TV',
        ]);
        \App\Models\Middle::create([
            'id' => 2,
            'name' => 'Rádio',
        ]);
        \App\Models\Middle::create([
            'id' => 3,
            'name' => 'Impresso',
        ]);
        \App\Models\Middle::create([
            'id' => 4,
            'name' => 'Rede Social',
        ]);
        \App\Models\Middle::create([
            'id' => 5,
            'name' => 'Site/Blog',
        ]);
    }
}
