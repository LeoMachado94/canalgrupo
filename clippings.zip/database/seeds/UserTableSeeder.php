<?php

use Illuminate\Database\Seeder;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\User::create([
            'name' => 'Admin',
            'email' => 'admin@admin.com',
            'password' => bcrypt('admin'),
        ]);
        \App\Models\User::create([
            'name' => 'Leonardo',
            'email' => 'leonardo@admin.com',
            'password' => bcrypt('admin'),
        ]);
    }
}
