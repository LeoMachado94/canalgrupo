<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
//         $this->call(\Guiliredu\BrazilianCityMigrationSeed\Database\Seeds\StateTableSeeder::class);
//         $this->call(\Guiliredu\BrazilianCityMigrationSeed\Database\Seeds\CityTableSeeder::class);
        $this->call(UserTableSeeder::class);
        $this->call(StateTableSeeder::class);
        $this->call(CityTableSeeder::class);
        $this->call(MiddleTableSeeder::class);
        $this->call(ClientTableSeeder::class);
        $this->call(SubjectTableSeeder::class);
    }
}
